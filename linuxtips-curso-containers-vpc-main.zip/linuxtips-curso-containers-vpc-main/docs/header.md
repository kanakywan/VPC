# Curso de Arquitetura de Containers na AWS - Aula 01 - VPC 

> Exemplos de implementação dos exercícios desenvolvidos na aula sobre criação e planejamento de VPC's de alta disponibilidade para arquiteturas de containers

## Arquitetura Inicial

![Arquitetura](/docs/Linuxtips-Containers-AWS-VPC%20Uso.drawio.png)


## Planejamento de Tamanho das Subnets

![Planejamento](/docs/Linuxtips-Containers-AWS-VPC%20-%20Planejamento.drawio.png)